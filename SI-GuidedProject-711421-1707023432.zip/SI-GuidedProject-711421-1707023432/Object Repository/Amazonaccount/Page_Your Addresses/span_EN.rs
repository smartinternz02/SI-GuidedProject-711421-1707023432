<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>span_EN</name>
   <tag></tag>
   <elementGuidId>b20eeb0d-611b-4bb3-a168-251d74bc8cf4</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>span.icp-nav-link-inner > span.nav-line-2</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//a[@id='icp-nav-flyout']/span/span[2]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
      <webElementGuid>17a8d9c7-5830-4f7c-8657-633442f99617</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>nav-line-2</value>
      <webElementGuid>cc8f3ff2-6782-4609-8408-9ce3aab0a4e0</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
        
          EN
        
      </value>
      <webElementGuid>cb217873-1ba1-4e9a-be44-e899c8f8636a</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;icp-nav-flyout&quot;)/span[@class=&quot;icp-nav-link-inner&quot;]/span[@class=&quot;nav-line-2&quot;]</value>
      <webElementGuid>6bde3218-2f54-4ced-9c25-dfc3e07f7fcd</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//a[@id='icp-nav-flyout']/span/span[2]</value>
      <webElementGuid>b81d7fb1-9d62-47f1-ac62-f7e4a1dc79e0</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//span/span[2]</value>
      <webElementGuid>442b48dc-31a6-43d6-9c95-d06fa9cca8ee</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//span[(text() = '
        
          EN
        
      ' or . = '
        
          EN
        
      ')]</value>
      <webElementGuid>39c3f091-2b3f-43a0-87bf-644122815dd7</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
