<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_Your Account                           _a77571</name>
   <tag></tag>
   <elementGuidId>828990d8-7a36-4b4b-861a-59b296c7dcee</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>div.a-section.a-spacing-medium.a-text-left.address-wide-container-desktop</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='a-page']/div/div</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>1a668d40-440b-40fe-aee2-3a0b0c2798fd</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>a-section a-spacing-medium a-text-left address-wide-container-desktop</value>
      <webElementGuid>88cd8c4c-2cd0-424e-a404-92af2a7d1ca3</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>



            
                
                         Your Account 
                
        
        ›

            
                
                     Your Addresses 
                
            






Your Addresses



Add Address





                Koppu vivek23-150/bNehru Nagar, NandigamaNANDIGAMA, ANDHRA PRADESH 521185IndiaPhone number: ‪9121996551‬{&quot;js-experiments-map&quot;:&quot;{\&quot;CJP_ARX_ADDRESS_INPUT_IMPROVEMENT_JP_777891\&quot; : \&quot;T1\&quot;, \&quot;A2I_ARX_CSDV_HK_NEW_ADDRESS_FORM_758825\&quot; : \&quot;C\&quot;, \&quot;A2I_ARX_CSDV_PH_NEW_ADDRESS_FORM_740031\&quot; : \&quot;T1\&quot;, \&quot;CJP_ARX_PIN_ON_MAPS_REVERSE_GEOCODING_707172\&quot; : \&quot;null\&quot;, \&quot;CJP_ARX_POM_OPTIMIZATION_VECTOR_DRAWING_646751\&quot; : \&quot;T1\&quot;, \&quot;CJ_ARX_NUMERIC_POSTAL_CODE_FORM_FIELD_IOS_673728\&quot; : \&quot;C\&quot;, \&quot;CJP_ARX_STREAMLINE_ADDRESS_INPUT_690024\&quot; : \&quot;null\&quot;, \&quot;CJP_ARX_PIN_ON_MAPS_STATIC_PIN_GATING_646876\&quot; : \&quot;T1\&quot;, \&quot;ARX_BR_FLEXIBLE_ADDRESS_FORM_WW_441095\&quot; : \&quot;T1\&quot;, \&quot;A2I_ARX_CSDV_NZ_NEW_ADDRESS_FORM_738112\&quot; : \&quot;T1\&quot;, \&quot;CJP_ARX_CL_FRESA_ADDRESS_FORM_573474\&quot; : \&quot;C\&quot;, \&quot;ARX_PREPOPULATE_NAME_AND_PHONE_MOBILE_420358\&quot; : \&quot;null\&quot;, \&quot;CJP_ARX_CDP_AUTO_EXPAND_DELIVERY_INSTRUCTIONS_667853\&quot; : \&quot;T1\&quot;, \&quot;CJ_ARX_SHOPPING_PORTAL_AJAX_COMPLETE_SHIFT_699695\&quot; : \&quot;T1\&quot;, \&quot;A2I_ARX_CSDV_CL_NEW_ADDRESS_FORM_776165\&quot; : \&quot;C\&quot;, \&quot;A2I_ARX_CSDV_IL_NEW_ADDRESS_FORM_757958\&quot; : \&quot;C\&quot;, \&quot;A2I_ARX_CSDV_CO_NEW_ADDRESS_FORM_760201\&quot; : \&quot;T1\&quot;, \&quot;ARX_AUTOFILL_POSTAL_CODE_401676\&quot; : \&quot;T1\&quot;, \&quot;CJP_ARX_PIN_ON_MAPS_USABILITY_CHANGES_567020\&quot; : \&quot;T2\&quot;, \&quot;CJP_ARX_ADDRESS_CREATION_REDESIGN_696914\&quot; : \&quot;null\&quot;, \&quot;CJP_ARX_PIN_ON_MAPS_STATIC_PIN_645293\&quot; : \&quot;T2\&quot;, \&quot;CJP_ARX_NG_FRESA_ADDRESS_FORM_573476\&quot; : \&quot;C\&quot;, \&quot;CJP_ARX_POM_OPTIMIZATION_INTRODUCE_DMQ_646752\&quot; : \&quot;null\&quot;, \&quot;ARX_ADDRESS_ZIP_DYNAMIC_VALIDATION_461972\&quot; : \&quot;T1\&quot;, \&quot;CJP_ARX_PINCODE_CITY_MISMATCH_689089\&quot; : \&quot;C\&quot;, \&quot;A2I_ARX_CSDV_COUNTRY_DROPDOWN_WITH_FLAG_742851\&quot; : \&quot;C\&quot;, \&quot;ARX_REMOVE_AUTOFILL_DETECT_LOCATION_BR_489857\&quot; : \&quot;C\&quot;, \&quot;ARX_DETECT_LOCATION_DESKTOP_416710\&quot; : \&quot;T3\&quot;, \&quot;CJ_ARX_ADDRESS_NAME_DYNAMIC_VALIDATION_696009\&quot; : \&quot;T1\&quot;, \&quot;CJ_ARX_ADDRESS_PHONE_DYNAMIC_VALIDATION_696011\&quot; : \&quot;null\&quot;, \&quot;A2I_ARX_CSDV_TW_NEW_ADDRESS_FORM_756323\&quot; : \&quot;C\&quot;, \&quot;A2I_ARX_CSDV_KR_NEW_ADDRESS_FORM_769560\&quot; : \&quot;T1\&quot;, \&quot;CJP_ARX_PIN_ON_MAPS_BUGS_BATCH_1_566923\&quot; : \&quot;null\&quot;, \&quot;CJP_ARX_CO_FRESA_ADDRESS_FORM_573475\&quot; : \&quot;C\&quot;, \&quot;CJP_ARX_PIN_ON_MAPS_SEARCH_ADOPTION_TRACKER_596079\&quot; : \&quot;null\&quot;}&quot;}

  (window.AmazonUIPageJS ? AmazonUIPageJS : P).load.js('https://images-na.ssl-images-amazon.com/images/I/51TfDpXMc5L._RC|919FzvBluRL.js_.js?AUIClients/AddressUIWidgetsServiceAssets&amp;EGnLwhIn#336856-T1.705340-T1');









{&quot;editBehavior&quot;:&quot;none&quot;,&quot;arfClientId&quot;:&quot;none&quot;,&quot;deleteBehavior&quot;:&quot;none&quot;,&quot;enabled&quot;:false}
Edit               |  

Remove



      Koppu vivek23-150/bNehru Nagar, NandigamaNANDIGAMA, ANDHRA PRADESH 521185IndiaPhone number: ‪9121996551‬{&quot;js-experiments-map&quot;:&quot;{\&quot;CJP_ARX_ADDRESS_INPUT_IMPROVEMENT_JP_777891\&quot; : \&quot;T1\&quot;, \&quot;A2I_ARX_CSDV_HK_NEW_ADDRESS_FORM_758825\&quot; : \&quot;C\&quot;, \&quot;A2I_ARX_CSDV_PH_NEW_ADDRESS_FORM_740031\&quot; : \&quot;T1\&quot;, \&quot;CJP_ARX_PIN_ON_MAPS_REVERSE_GEOCODING_707172\&quot; : \&quot;null\&quot;, \&quot;CJP_ARX_POM_OPTIMIZATION_VECTOR_DRAWING_646751\&quot; : \&quot;T1\&quot;, \&quot;CJ_ARX_NUMERIC_POSTAL_CODE_FORM_FIELD_IOS_673728\&quot; : \&quot;C\&quot;, \&quot;CJP_ARX_STREAMLINE_ADDRESS_INPUT_690024\&quot; : \&quot;null\&quot;, \&quot;CJP_ARX_PIN_ON_MAPS_STATIC_PIN_GATING_646876\&quot; : \&quot;T1\&quot;, \&quot;ARX_BR_FLEXIBLE_ADDRESS_FORM_WW_441095\&quot; : \&quot;T1\&quot;, \&quot;A2I_ARX_CSDV_NZ_NEW_ADDRESS_FORM_738112\&quot; : \&quot;T1\&quot;, \&quot;CJP_ARX_CL_FRESA_ADDRESS_FORM_573474\&quot; : \&quot;C\&quot;, \&quot;ARX_PREPOPULATE_NAME_AND_PHONE_MOBILE_420358\&quot; : \&quot;null\&quot;, \&quot;CJP_ARX_CDP_AUTO_EXPAND_DELIVERY_INSTRUCTIONS_667853\&quot; : \&quot;T1\&quot;, \&quot;CJ_ARX_SHOPPING_PORTAL_AJAX_COMPLETE_SHIFT_699695\&quot; : \&quot;T1\&quot;, \&quot;A2I_ARX_CSDV_CL_NEW_ADDRESS_FORM_776165\&quot; : \&quot;C\&quot;, \&quot;A2I_ARX_CSDV_IL_NEW_ADDRESS_FORM_757958\&quot; : \&quot;C\&quot;, \&quot;A2I_ARX_CSDV_CO_NEW_ADDRESS_FORM_760201\&quot; : \&quot;T1\&quot;, \&quot;ARX_AUTOFILL_POSTAL_CODE_401676\&quot; : \&quot;T1\&quot;, \&quot;CJP_ARX_PIN_ON_MAPS_USABILITY_CHANGES_567020\&quot; : \&quot;T2\&quot;, \&quot;CJP_ARX_ADDRESS_CREATION_REDESIGN_696914\&quot; : \&quot;null\&quot;, \&quot;CJP_ARX_PIN_ON_MAPS_STATIC_PIN_645293\&quot; : \&quot;T2\&quot;, \&quot;CJP_ARX_NG_FRESA_ADDRESS_FORM_573476\&quot; : \&quot;C\&quot;, \&quot;CJP_ARX_POM_OPTIMIZATION_INTRODUCE_DMQ_646752\&quot; : \&quot;null\&quot;, \&quot;ARX_ADDRESS_ZIP_DYNAMIC_VALIDATION_461972\&quot; : \&quot;T1\&quot;, \&quot;CJP_ARX_PINCODE_CITY_MISMATCH_689089\&quot; : \&quot;C\&quot;, \&quot;A2I_ARX_CSDV_COUNTRY_DROPDOWN_WITH_FLAG_742851\&quot; : \&quot;C\&quot;, \&quot;ARX_REMOVE_AUTOFILL_DETECT_LOCATION_BR_489857\&quot; : \&quot;C\&quot;, \&quot;ARX_DETECT_LOCATION_DESKTOP_416710\&quot; : \&quot;T3\&quot;, \&quot;CJ_ARX_ADDRESS_NAME_DYNAMIC_VALIDATION_696009\&quot; : \&quot;T1\&quot;, \&quot;CJ_ARX_ADDRESS_PHONE_DYNAMIC_VALIDATION_696011\&quot; : \&quot;null\&quot;, \&quot;A2I_ARX_CSDV_TW_NEW_ADDRESS_FORM_756323\&quot; : \&quot;C\&quot;, \&quot;A2I_ARX_CSDV_KR_NEW_ADDRESS_FORM_769560\&quot; : \&quot;T1\&quot;, \&quot;CJP_ARX_PIN_ON_MAPS_BUGS_BATCH_1_566923\&quot; : \&quot;null\&quot;, \&quot;CJP_ARX_CO_FRESA_ADDRESS_FORM_573475\&quot; : \&quot;C\&quot;, \&quot;CJP_ARX_PIN_ON_MAPS_SEARCH_ADOPTION_TRACKER_596079\&quot; : \&quot;null\&quot;}&quot;}

  (window.AmazonUIPageJS ? AmazonUIPageJS : P).load.js('https://images-na.ssl-images-amazon.com/images/I/51TfDpXMc5L._RC|919FzvBluRL.js_.js?AUIClients/AddressUIWidgetsServiceAssets&amp;EGnLwhIn#336856-T1.705340-T1');




Please note: Removing this address will not affect any pending orders being shipped to this address. To ensure uninterrupted fulfillment of future orders, please update any wishlists, subscribe and save settings and periodical subscriptions using this address.
No
Yes


                  |  
Set as Default
Related
              1-Click Settings  
              Change address on an open order  
</value>
      <webElementGuid>a4216a28-57c7-484d-9cd8-2ed9ed975d96</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;a-page&quot;)/div[@class=&quot;a-section&quot;]/div[@class=&quot;a-section a-spacing-medium a-text-left address-wide-container-desktop&quot;]</value>
      <webElementGuid>c1b8e4ed-6871-435d-926c-b4b22a445033</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='a-page']/div/div</value>
      <webElementGuid>0b41f309-62ce-4111-b57c-7a54ca53b434</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div/div/div</value>
      <webElementGuid>06558b87-67ec-4946-bf1a-4f31ba3947cf</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = concat(&quot;



            
                
                         Your Account 
                
        
        ›

            
                
                     Your Addresses 
                
            






Your Addresses



Add Address





                Koppu vivek23-150/bNehru Nagar, NandigamaNANDIGAMA, ANDHRA PRADESH 521185IndiaPhone number: ‪9121996551‬{&quot;js-experiments-map&quot;:&quot;{\&quot;CJP_ARX_ADDRESS_INPUT_IMPROVEMENT_JP_777891\&quot; : \&quot;T1\&quot;, \&quot;A2I_ARX_CSDV_HK_NEW_ADDRESS_FORM_758825\&quot; : \&quot;C\&quot;, \&quot;A2I_ARX_CSDV_PH_NEW_ADDRESS_FORM_740031\&quot; : \&quot;T1\&quot;, \&quot;CJP_ARX_PIN_ON_MAPS_REVERSE_GEOCODING_707172\&quot; : \&quot;null\&quot;, \&quot;CJP_ARX_POM_OPTIMIZATION_VECTOR_DRAWING_646751\&quot; : \&quot;T1\&quot;, \&quot;CJ_ARX_NUMERIC_POSTAL_CODE_FORM_FIELD_IOS_673728\&quot; : \&quot;C\&quot;, \&quot;CJP_ARX_STREAMLINE_ADDRESS_INPUT_690024\&quot; : \&quot;null\&quot;, \&quot;CJP_ARX_PIN_ON_MAPS_STATIC_PIN_GATING_646876\&quot; : \&quot;T1\&quot;, \&quot;ARX_BR_FLEXIBLE_ADDRESS_FORM_WW_441095\&quot; : \&quot;T1\&quot;, \&quot;A2I_ARX_CSDV_NZ_NEW_ADDRESS_FORM_738112\&quot; : \&quot;T1\&quot;, \&quot;CJP_ARX_CL_FRESA_ADDRESS_FORM_573474\&quot; : \&quot;C\&quot;, \&quot;ARX_PREPOPULATE_NAME_AND_PHONE_MOBILE_420358\&quot; : \&quot;null\&quot;, \&quot;CJP_ARX_CDP_AUTO_EXPAND_DELIVERY_INSTRUCTIONS_667853\&quot; : \&quot;T1\&quot;, \&quot;CJ_ARX_SHOPPING_PORTAL_AJAX_COMPLETE_SHIFT_699695\&quot; : \&quot;T1\&quot;, \&quot;A2I_ARX_CSDV_CL_NEW_ADDRESS_FORM_776165\&quot; : \&quot;C\&quot;, \&quot;A2I_ARX_CSDV_IL_NEW_ADDRESS_FORM_757958\&quot; : \&quot;C\&quot;, \&quot;A2I_ARX_CSDV_CO_NEW_ADDRESS_FORM_760201\&quot; : \&quot;T1\&quot;, \&quot;ARX_AUTOFILL_POSTAL_CODE_401676\&quot; : \&quot;T1\&quot;, \&quot;CJP_ARX_PIN_ON_MAPS_USABILITY_CHANGES_567020\&quot; : \&quot;T2\&quot;, \&quot;CJP_ARX_ADDRESS_CREATION_REDESIGN_696914\&quot; : \&quot;null\&quot;, \&quot;CJP_ARX_PIN_ON_MAPS_STATIC_PIN_645293\&quot; : \&quot;T2\&quot;, \&quot;CJP_ARX_NG_FRESA_ADDRESS_FORM_573476\&quot; : \&quot;C\&quot;, \&quot;CJP_ARX_POM_OPTIMIZATION_INTRODUCE_DMQ_646752\&quot; : \&quot;null\&quot;, \&quot;ARX_ADDRESS_ZIP_DYNAMIC_VALIDATION_461972\&quot; : \&quot;T1\&quot;, \&quot;CJP_ARX_PINCODE_CITY_MISMATCH_689089\&quot; : \&quot;C\&quot;, \&quot;A2I_ARX_CSDV_COUNTRY_DROPDOWN_WITH_FLAG_742851\&quot; : \&quot;C\&quot;, \&quot;ARX_REMOVE_AUTOFILL_DETECT_LOCATION_BR_489857\&quot; : \&quot;C\&quot;, \&quot;ARX_DETECT_LOCATION_DESKTOP_416710\&quot; : \&quot;T3\&quot;, \&quot;CJ_ARX_ADDRESS_NAME_DYNAMIC_VALIDATION_696009\&quot; : \&quot;T1\&quot;, \&quot;CJ_ARX_ADDRESS_PHONE_DYNAMIC_VALIDATION_696011\&quot; : \&quot;null\&quot;, \&quot;A2I_ARX_CSDV_TW_NEW_ADDRESS_FORM_756323\&quot; : \&quot;C\&quot;, \&quot;A2I_ARX_CSDV_KR_NEW_ADDRESS_FORM_769560\&quot; : \&quot;T1\&quot;, \&quot;CJP_ARX_PIN_ON_MAPS_BUGS_BATCH_1_566923\&quot; : \&quot;null\&quot;, \&quot;CJP_ARX_CO_FRESA_ADDRESS_FORM_573475\&quot; : \&quot;C\&quot;, \&quot;CJP_ARX_PIN_ON_MAPS_SEARCH_ADOPTION_TRACKER_596079\&quot; : \&quot;null\&quot;}&quot;}

  (window.AmazonUIPageJS ? AmazonUIPageJS : P).load.js(&quot; , &quot;'&quot; , &quot;https://images-na.ssl-images-amazon.com/images/I/51TfDpXMc5L._RC|919FzvBluRL.js_.js?AUIClients/AddressUIWidgetsServiceAssets&amp;EGnLwhIn#336856-T1.705340-T1&quot; , &quot;'&quot; , &quot;);









{&quot;editBehavior&quot;:&quot;none&quot;,&quot;arfClientId&quot;:&quot;none&quot;,&quot;deleteBehavior&quot;:&quot;none&quot;,&quot;enabled&quot;:false}
Edit               |  

Remove



      Koppu vivek23-150/bNehru Nagar, NandigamaNANDIGAMA, ANDHRA PRADESH 521185IndiaPhone number: ‪9121996551‬{&quot;js-experiments-map&quot;:&quot;{\&quot;CJP_ARX_ADDRESS_INPUT_IMPROVEMENT_JP_777891\&quot; : \&quot;T1\&quot;, \&quot;A2I_ARX_CSDV_HK_NEW_ADDRESS_FORM_758825\&quot; : \&quot;C\&quot;, \&quot;A2I_ARX_CSDV_PH_NEW_ADDRESS_FORM_740031\&quot; : \&quot;T1\&quot;, \&quot;CJP_ARX_PIN_ON_MAPS_REVERSE_GEOCODING_707172\&quot; : \&quot;null\&quot;, \&quot;CJP_ARX_POM_OPTIMIZATION_VECTOR_DRAWING_646751\&quot; : \&quot;T1\&quot;, \&quot;CJ_ARX_NUMERIC_POSTAL_CODE_FORM_FIELD_IOS_673728\&quot; : \&quot;C\&quot;, \&quot;CJP_ARX_STREAMLINE_ADDRESS_INPUT_690024\&quot; : \&quot;null\&quot;, \&quot;CJP_ARX_PIN_ON_MAPS_STATIC_PIN_GATING_646876\&quot; : \&quot;T1\&quot;, \&quot;ARX_BR_FLEXIBLE_ADDRESS_FORM_WW_441095\&quot; : \&quot;T1\&quot;, \&quot;A2I_ARX_CSDV_NZ_NEW_ADDRESS_FORM_738112\&quot; : \&quot;T1\&quot;, \&quot;CJP_ARX_CL_FRESA_ADDRESS_FORM_573474\&quot; : \&quot;C\&quot;, \&quot;ARX_PREPOPULATE_NAME_AND_PHONE_MOBILE_420358\&quot; : \&quot;null\&quot;, \&quot;CJP_ARX_CDP_AUTO_EXPAND_DELIVERY_INSTRUCTIONS_667853\&quot; : \&quot;T1\&quot;, \&quot;CJ_ARX_SHOPPING_PORTAL_AJAX_COMPLETE_SHIFT_699695\&quot; : \&quot;T1\&quot;, \&quot;A2I_ARX_CSDV_CL_NEW_ADDRESS_FORM_776165\&quot; : \&quot;C\&quot;, \&quot;A2I_ARX_CSDV_IL_NEW_ADDRESS_FORM_757958\&quot; : \&quot;C\&quot;, \&quot;A2I_ARX_CSDV_CO_NEW_ADDRESS_FORM_760201\&quot; : \&quot;T1\&quot;, \&quot;ARX_AUTOFILL_POSTAL_CODE_401676\&quot; : \&quot;T1\&quot;, \&quot;CJP_ARX_PIN_ON_MAPS_USABILITY_CHANGES_567020\&quot; : \&quot;T2\&quot;, \&quot;CJP_ARX_ADDRESS_CREATION_REDESIGN_696914\&quot; : \&quot;null\&quot;, \&quot;CJP_ARX_PIN_ON_MAPS_STATIC_PIN_645293\&quot; : \&quot;T2\&quot;, \&quot;CJP_ARX_NG_FRESA_ADDRESS_FORM_573476\&quot; : \&quot;C\&quot;, \&quot;CJP_ARX_POM_OPTIMIZATION_INTRODUCE_DMQ_646752\&quot; : \&quot;null\&quot;, \&quot;ARX_ADDRESS_ZIP_DYNAMIC_VALIDATION_461972\&quot; : \&quot;T1\&quot;, \&quot;CJP_ARX_PINCODE_CITY_MISMATCH_689089\&quot; : \&quot;C\&quot;, \&quot;A2I_ARX_CSDV_COUNTRY_DROPDOWN_WITH_FLAG_742851\&quot; : \&quot;C\&quot;, \&quot;ARX_REMOVE_AUTOFILL_DETECT_LOCATION_BR_489857\&quot; : \&quot;C\&quot;, \&quot;ARX_DETECT_LOCATION_DESKTOP_416710\&quot; : \&quot;T3\&quot;, \&quot;CJ_ARX_ADDRESS_NAME_DYNAMIC_VALIDATION_696009\&quot; : \&quot;T1\&quot;, \&quot;CJ_ARX_ADDRESS_PHONE_DYNAMIC_VALIDATION_696011\&quot; : \&quot;null\&quot;, \&quot;A2I_ARX_CSDV_TW_NEW_ADDRESS_FORM_756323\&quot; : \&quot;C\&quot;, \&quot;A2I_ARX_CSDV_KR_NEW_ADDRESS_FORM_769560\&quot; : \&quot;T1\&quot;, \&quot;CJP_ARX_PIN_ON_MAPS_BUGS_BATCH_1_566923\&quot; : \&quot;null\&quot;, \&quot;CJP_ARX_CO_FRESA_ADDRESS_FORM_573475\&quot; : \&quot;C\&quot;, \&quot;CJP_ARX_PIN_ON_MAPS_SEARCH_ADOPTION_TRACKER_596079\&quot; : \&quot;null\&quot;}&quot;}

  (window.AmazonUIPageJS ? AmazonUIPageJS : P).load.js(&quot; , &quot;'&quot; , &quot;https://images-na.ssl-images-amazon.com/images/I/51TfDpXMc5L._RC|919FzvBluRL.js_.js?AUIClients/AddressUIWidgetsServiceAssets&amp;EGnLwhIn#336856-T1.705340-T1&quot; , &quot;'&quot; , &quot;);




Please note: Removing this address will not affect any pending orders being shipped to this address. To ensure uninterrupted fulfillment of future orders, please update any wishlists, subscribe and save settings and periodical subscriptions using this address.
No
Yes


                  |  
Set as Default
Related
              1-Click Settings  
              Change address on an open order  
&quot;) or . = concat(&quot;



            
                
                         Your Account 
                
        
        ›

            
                
                     Your Addresses 
                
            






Your Addresses



Add Address





                Koppu vivek23-150/bNehru Nagar, NandigamaNANDIGAMA, ANDHRA PRADESH 521185IndiaPhone number: ‪9121996551‬{&quot;js-experiments-map&quot;:&quot;{\&quot;CJP_ARX_ADDRESS_INPUT_IMPROVEMENT_JP_777891\&quot; : \&quot;T1\&quot;, \&quot;A2I_ARX_CSDV_HK_NEW_ADDRESS_FORM_758825\&quot; : \&quot;C\&quot;, \&quot;A2I_ARX_CSDV_PH_NEW_ADDRESS_FORM_740031\&quot; : \&quot;T1\&quot;, \&quot;CJP_ARX_PIN_ON_MAPS_REVERSE_GEOCODING_707172\&quot; : \&quot;null\&quot;, \&quot;CJP_ARX_POM_OPTIMIZATION_VECTOR_DRAWING_646751\&quot; : \&quot;T1\&quot;, \&quot;CJ_ARX_NUMERIC_POSTAL_CODE_FORM_FIELD_IOS_673728\&quot; : \&quot;C\&quot;, \&quot;CJP_ARX_STREAMLINE_ADDRESS_INPUT_690024\&quot; : \&quot;null\&quot;, \&quot;CJP_ARX_PIN_ON_MAPS_STATIC_PIN_GATING_646876\&quot; : \&quot;T1\&quot;, \&quot;ARX_BR_FLEXIBLE_ADDRESS_FORM_WW_441095\&quot; : \&quot;T1\&quot;, \&quot;A2I_ARX_CSDV_NZ_NEW_ADDRESS_FORM_738112\&quot; : \&quot;T1\&quot;, \&quot;CJP_ARX_CL_FRESA_ADDRESS_FORM_573474\&quot; : \&quot;C\&quot;, \&quot;ARX_PREPOPULATE_NAME_AND_PHONE_MOBILE_420358\&quot; : \&quot;null\&quot;, \&quot;CJP_ARX_CDP_AUTO_EXPAND_DELIVERY_INSTRUCTIONS_667853\&quot; : \&quot;T1\&quot;, \&quot;CJ_ARX_SHOPPING_PORTAL_AJAX_COMPLETE_SHIFT_699695\&quot; : \&quot;T1\&quot;, \&quot;A2I_ARX_CSDV_CL_NEW_ADDRESS_FORM_776165\&quot; : \&quot;C\&quot;, \&quot;A2I_ARX_CSDV_IL_NEW_ADDRESS_FORM_757958\&quot; : \&quot;C\&quot;, \&quot;A2I_ARX_CSDV_CO_NEW_ADDRESS_FORM_760201\&quot; : \&quot;T1\&quot;, \&quot;ARX_AUTOFILL_POSTAL_CODE_401676\&quot; : \&quot;T1\&quot;, \&quot;CJP_ARX_PIN_ON_MAPS_USABILITY_CHANGES_567020\&quot; : \&quot;T2\&quot;, \&quot;CJP_ARX_ADDRESS_CREATION_REDESIGN_696914\&quot; : \&quot;null\&quot;, \&quot;CJP_ARX_PIN_ON_MAPS_STATIC_PIN_645293\&quot; : \&quot;T2\&quot;, \&quot;CJP_ARX_NG_FRESA_ADDRESS_FORM_573476\&quot; : \&quot;C\&quot;, \&quot;CJP_ARX_POM_OPTIMIZATION_INTRODUCE_DMQ_646752\&quot; : \&quot;null\&quot;, \&quot;ARX_ADDRESS_ZIP_DYNAMIC_VALIDATION_461972\&quot; : \&quot;T1\&quot;, \&quot;CJP_ARX_PINCODE_CITY_MISMATCH_689089\&quot; : \&quot;C\&quot;, \&quot;A2I_ARX_CSDV_COUNTRY_DROPDOWN_WITH_FLAG_742851\&quot; : \&quot;C\&quot;, \&quot;ARX_REMOVE_AUTOFILL_DETECT_LOCATION_BR_489857\&quot; : \&quot;C\&quot;, \&quot;ARX_DETECT_LOCATION_DESKTOP_416710\&quot; : \&quot;T3\&quot;, \&quot;CJ_ARX_ADDRESS_NAME_DYNAMIC_VALIDATION_696009\&quot; : \&quot;T1\&quot;, \&quot;CJ_ARX_ADDRESS_PHONE_DYNAMIC_VALIDATION_696011\&quot; : \&quot;null\&quot;, \&quot;A2I_ARX_CSDV_TW_NEW_ADDRESS_FORM_756323\&quot; : \&quot;C\&quot;, \&quot;A2I_ARX_CSDV_KR_NEW_ADDRESS_FORM_769560\&quot; : \&quot;T1\&quot;, \&quot;CJP_ARX_PIN_ON_MAPS_BUGS_BATCH_1_566923\&quot; : \&quot;null\&quot;, \&quot;CJP_ARX_CO_FRESA_ADDRESS_FORM_573475\&quot; : \&quot;C\&quot;, \&quot;CJP_ARX_PIN_ON_MAPS_SEARCH_ADOPTION_TRACKER_596079\&quot; : \&quot;null\&quot;}&quot;}

  (window.AmazonUIPageJS ? AmazonUIPageJS : P).load.js(&quot; , &quot;'&quot; , &quot;https://images-na.ssl-images-amazon.com/images/I/51TfDpXMc5L._RC|919FzvBluRL.js_.js?AUIClients/AddressUIWidgetsServiceAssets&amp;EGnLwhIn#336856-T1.705340-T1&quot; , &quot;'&quot; , &quot;);









{&quot;editBehavior&quot;:&quot;none&quot;,&quot;arfClientId&quot;:&quot;none&quot;,&quot;deleteBehavior&quot;:&quot;none&quot;,&quot;enabled&quot;:false}
Edit               |  

Remove



      Koppu vivek23-150/bNehru Nagar, NandigamaNANDIGAMA, ANDHRA PRADESH 521185IndiaPhone number: ‪9121996551‬{&quot;js-experiments-map&quot;:&quot;{\&quot;CJP_ARX_ADDRESS_INPUT_IMPROVEMENT_JP_777891\&quot; : \&quot;T1\&quot;, \&quot;A2I_ARX_CSDV_HK_NEW_ADDRESS_FORM_758825\&quot; : \&quot;C\&quot;, \&quot;A2I_ARX_CSDV_PH_NEW_ADDRESS_FORM_740031\&quot; : \&quot;T1\&quot;, \&quot;CJP_ARX_PIN_ON_MAPS_REVERSE_GEOCODING_707172\&quot; : \&quot;null\&quot;, \&quot;CJP_ARX_POM_OPTIMIZATION_VECTOR_DRAWING_646751\&quot; : \&quot;T1\&quot;, \&quot;CJ_ARX_NUMERIC_POSTAL_CODE_FORM_FIELD_IOS_673728\&quot; : \&quot;C\&quot;, \&quot;CJP_ARX_STREAMLINE_ADDRESS_INPUT_690024\&quot; : \&quot;null\&quot;, \&quot;CJP_ARX_PIN_ON_MAPS_STATIC_PIN_GATING_646876\&quot; : \&quot;T1\&quot;, \&quot;ARX_BR_FLEXIBLE_ADDRESS_FORM_WW_441095\&quot; : \&quot;T1\&quot;, \&quot;A2I_ARX_CSDV_NZ_NEW_ADDRESS_FORM_738112\&quot; : \&quot;T1\&quot;, \&quot;CJP_ARX_CL_FRESA_ADDRESS_FORM_573474\&quot; : \&quot;C\&quot;, \&quot;ARX_PREPOPULATE_NAME_AND_PHONE_MOBILE_420358\&quot; : \&quot;null\&quot;, \&quot;CJP_ARX_CDP_AUTO_EXPAND_DELIVERY_INSTRUCTIONS_667853\&quot; : \&quot;T1\&quot;, \&quot;CJ_ARX_SHOPPING_PORTAL_AJAX_COMPLETE_SHIFT_699695\&quot; : \&quot;T1\&quot;, \&quot;A2I_ARX_CSDV_CL_NEW_ADDRESS_FORM_776165\&quot; : \&quot;C\&quot;, \&quot;A2I_ARX_CSDV_IL_NEW_ADDRESS_FORM_757958\&quot; : \&quot;C\&quot;, \&quot;A2I_ARX_CSDV_CO_NEW_ADDRESS_FORM_760201\&quot; : \&quot;T1\&quot;, \&quot;ARX_AUTOFILL_POSTAL_CODE_401676\&quot; : \&quot;T1\&quot;, \&quot;CJP_ARX_PIN_ON_MAPS_USABILITY_CHANGES_567020\&quot; : \&quot;T2\&quot;, \&quot;CJP_ARX_ADDRESS_CREATION_REDESIGN_696914\&quot; : \&quot;null\&quot;, \&quot;CJP_ARX_PIN_ON_MAPS_STATIC_PIN_645293\&quot; : \&quot;T2\&quot;, \&quot;CJP_ARX_NG_FRESA_ADDRESS_FORM_573476\&quot; : \&quot;C\&quot;, \&quot;CJP_ARX_POM_OPTIMIZATION_INTRODUCE_DMQ_646752\&quot; : \&quot;null\&quot;, \&quot;ARX_ADDRESS_ZIP_DYNAMIC_VALIDATION_461972\&quot; : \&quot;T1\&quot;, \&quot;CJP_ARX_PINCODE_CITY_MISMATCH_689089\&quot; : \&quot;C\&quot;, \&quot;A2I_ARX_CSDV_COUNTRY_DROPDOWN_WITH_FLAG_742851\&quot; : \&quot;C\&quot;, \&quot;ARX_REMOVE_AUTOFILL_DETECT_LOCATION_BR_489857\&quot; : \&quot;C\&quot;, \&quot;ARX_DETECT_LOCATION_DESKTOP_416710\&quot; : \&quot;T3\&quot;, \&quot;CJ_ARX_ADDRESS_NAME_DYNAMIC_VALIDATION_696009\&quot; : \&quot;T1\&quot;, \&quot;CJ_ARX_ADDRESS_PHONE_DYNAMIC_VALIDATION_696011\&quot; : \&quot;null\&quot;, \&quot;A2I_ARX_CSDV_TW_NEW_ADDRESS_FORM_756323\&quot; : \&quot;C\&quot;, \&quot;A2I_ARX_CSDV_KR_NEW_ADDRESS_FORM_769560\&quot; : \&quot;T1\&quot;, \&quot;CJP_ARX_PIN_ON_MAPS_BUGS_BATCH_1_566923\&quot; : \&quot;null\&quot;, \&quot;CJP_ARX_CO_FRESA_ADDRESS_FORM_573475\&quot; : \&quot;C\&quot;, \&quot;CJP_ARX_PIN_ON_MAPS_SEARCH_ADOPTION_TRACKER_596079\&quot; : \&quot;null\&quot;}&quot;}

  (window.AmazonUIPageJS ? AmazonUIPageJS : P).load.js(&quot; , &quot;'&quot; , &quot;https://images-na.ssl-images-amazon.com/images/I/51TfDpXMc5L._RC|919FzvBluRL.js_.js?AUIClients/AddressUIWidgetsServiceAssets&amp;EGnLwhIn#336856-T1.705340-T1&quot; , &quot;'&quot; , &quot;);




Please note: Removing this address will not affect any pending orders being shipped to this address. To ensure uninterrupted fulfillment of future orders, please update any wishlists, subscribe and save settings and periodical subscriptions using this address.
No
Yes


                  |  
Set as Default
Related
              1-Click Settings  
              Change address on an open order  
&quot;))]</value>
      <webElementGuid>1a7eb98b-d25d-4455-95ab-cb51cd40a269</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
