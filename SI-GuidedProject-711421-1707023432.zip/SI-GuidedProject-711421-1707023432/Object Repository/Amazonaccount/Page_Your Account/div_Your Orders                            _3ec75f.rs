<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_Your Orders                            _3ec75f</name>
   <tag></tag>
   <elementGuidId>fce02f25-0420-436c-932b-24164aa619df</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>div.a-box-inner</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='a-page']/div/div/div[2]/div/a/div/div</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>e435f9d8-9a10-4980-8fb8-9566b9fc60f9</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>a-box-inner</value>
      <webElementGuid>f452531e-f1f9-46ce-ac58-03227cb059fb</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
        
            
                
            
            
                
                    Your Orders
                
                Track, return, cancel an order, download invoice or buy again
                
            
        
    </value>
      <webElementGuid>1e903079-d3d5-4299-a182-670e28c8c082</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;a-page&quot;)/div[@class=&quot;a-container&quot;]/div[@class=&quot;a-section ya-personalized&quot;]/div[@class=&quot;ya-card-row&quot;]/div[@class=&quot;ya-card-cell&quot;]/a[@class=&quot;ya-card__whole-card-link&quot;]/div[@class=&quot;a-box ya-card--rich&quot;]/div[@class=&quot;a-box-inner&quot;]</value>
      <webElementGuid>2e32672c-fea5-4c11-95ab-fcaec5a2c306</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='a-page']/div/div/div[2]/div/a/div/div</value>
      <webElementGuid>d328f356-50d7-44fc-8f02-4afd0abead3e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//a/div/div</value>
      <webElementGuid>88631137-120d-4a39-b586-b3c123f34748</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = '
        
            
                
            
            
                
                    Your Orders
                
                Track, return, cancel an order, download invoice or buy again
                
            
        
    ' or . = '
        
            
                
            
            
                
                    Your Orders
                
                Track, return, cancel an order, download invoice or buy again
                
            
        
    ')]</value>
      <webElementGuid>b1cb2119-f82d-4ce3-a5cc-abfaf493d9bd</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
