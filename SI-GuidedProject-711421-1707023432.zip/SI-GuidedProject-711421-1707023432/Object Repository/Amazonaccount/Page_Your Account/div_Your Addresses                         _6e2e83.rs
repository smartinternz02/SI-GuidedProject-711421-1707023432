<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_Your Addresses                         _6e2e83</name>
   <tag></tag>
   <elementGuidId>ab2802f6-ddf8-4b5a-ad91-1204498bece1</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value></value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='a-page']/div/div/div[3]/div/a/div/div</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>4fd38816-f21a-4f1e-820e-f406f1a34161</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>a-box-inner</value>
      <webElementGuid>54c20991-1855-4b50-99a2-aecd7dd4b0ab</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
        
            
                
            
            
                
                    Your Addresses
                
                Edit, remove or set default address
                
            
        
    </value>
      <webElementGuid>0a9826b7-ecb8-417b-aed7-057494c7fef7</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;a-page&quot;)/div[@class=&quot;a-container&quot;]/div[@class=&quot;a-section ya-personalized&quot;]/div[@class=&quot;ya-card-row&quot;]/div[@class=&quot;ya-card-cell&quot;]/a[@class=&quot;ya-card__whole-card-link&quot;]/div[@class=&quot;a-box ya-card--rich&quot;]/div[@class=&quot;a-box-inner&quot;]</value>
      <webElementGuid>41be9536-4fbf-4b7c-b3ec-51bf189c3496</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='a-page']/div/div/div[3]/div/a/div/div</value>
      <webElementGuid>6721db78-7043-407c-bb60-fcb758f92b84</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[3]/div/a/div/div</value>
      <webElementGuid>95fe4493-f901-4d53-b973-1eef97e214d6</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = '
        
            
                
            
            
                
                    Your Addresses
                
                Edit, remove or set default address
                
            
        
    ' or . = '
        
            
                
            
            
                
                    Your Addresses
                
                Edit, remove or set default address
                
            
        
    ')]</value>
      <webElementGuid>7c737ad4-6263-498f-b666-75e3b87e7bb7</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
