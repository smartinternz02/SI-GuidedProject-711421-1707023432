<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_Your Account                           _d89d91</name>
   <tag></tag>
   <elementGuidId>bdeffd4e-c0e5-4774-bc0e-2669027c2eb9</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>div.your-orders-content-container__content.js-yo-main-content</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='a-page']/section/div</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>e38a74c6-20cb-44f2-9801-0854d8a64a6e</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>your-orders-content-container__content js-yo-main-content</value>
      <webElementGuid>7e11cffe-dbc9-47d0-839d-55eb780cd67c</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
        
        


    
        
            
                
                    Your Account
                
                ›
            
        
            
                
                    Your Orders
                
            
        
    




    
        Your Orders
    
    
        
    
        
        
        
            
            
        
        
            Search Orders
        
    


    



    
        
            
                
                    Orders
                
            
        
            
                
                    Buy Again
                
            
        
            
                
                    Not Yet Shipped
                
            
        
            
                
                    Digital Orders
                
            
        
            
                
                    Local Store Orders
                
            
        
            
                
                    Cancelled Orders
                
            
        
    



    
        
            
    0 orders placed in

            
    
        
            last 30 days
        
    
        
            past 3 months
        
    
        
            2024
        
    
        
            2023
        
    
        
            2022
        
    
        
            2021
        
    
        
            2020
        
    
        
            2019
        
    
        
            Archived Orders
        
    

            past 3 months
        
        

        
            
        
    
    
        P.declare(&quot;time-filter-form-ready&quot;, {});
    



        

        
    An item you bought has been recalled
    To ensure your safety, go to Your Recalls and Product Safety Alerts and see recall information.



    .page-banner--hidden-by-default {
        display: none;
    }



    Action is required on one or more of your orders. 
    Please see below.



    .page-banner--hidden-by-default {
        display: none;
    }



    There's a problem displaying your orders right now.
    



    .page-banner--hidden-by-default {
        display: none;
    }



    Shape the future of Amazon Digital Subscriptions.
    We have made updates to the Your Orders Page. Click here to &quot;Opt In&quot; to view the changes and/or provide your feedback. If you spot an issue, please report the bug here. For critical issues (Sev2+), please use TT.



    .page-banner--hidden-by-default {
        display: none;
    }








        
            
    
        Looks like you haven't placed an order in the last 3 months.
        
            View orders in 2024
        
    

    
    if (typeof uet === &quot;function&quot;) { uet('cf'); }





    


    
    if (typeof uet === &quot;function&quot;) { uet('af'); }





    


    


        

        
        

        

        
            

    
    
    




        
    </value>
      <webElementGuid>be4da93e-0219-47d1-83dd-829a98e14f6e</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[@class=&quot;a-js a-audio a-video a-canvas a-svg a-drag-drop a-geolocation a-history a-webworker a-autofocus a-input-placeholder a-textarea-placeholder a-local-storage a-gradients a-transform3d a-touch-scrolling a-text-shadow a-text-stroke a-box-shadow a-border-radius a-border-image a-opacity a-transform a-transition a-ember&quot;]/body[@class=&quot;a-m-us a-aui_72554-c a-aui_a11y_1_699934-c a-aui_a11y_4_835613-c a-aui_a11y_6_837773-c a-aui_a11y_sr_678508-c a-aui_killswitch_csa_logger_372963-c a-aui_pci_risk_banner_210084-c a-aui_preload_261698-c a-aui_rel_noreferrer_noopener_309527-c a-aui_template_weblab_cache_333406-c a-aui_tnr_v2_180836-c a-meter-animate&quot;]/div[@id=&quot;a-page&quot;]/section[@class=&quot;your-orders-content-container aok-relative js-yo-container&quot;]/div[@class=&quot;your-orders-content-container__content js-yo-main-content&quot;]</value>
      <webElementGuid>ed948a20-0ca0-4ae7-8bac-256d56d003fb</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='a-page']/section/div</value>
      <webElementGuid>a41108f3-432f-455f-816f-5e20e5d95048</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//section/div</value>
      <webElementGuid>e38a2d77-a6dd-4ce5-90cf-e48dd093bbba</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = concat(&quot;
        
        


    
        
            
                
                    Your Account
                
                ›
            
        
            
                
                    Your Orders
                
            
        
    




    
        Your Orders
    
    
        
    
        
        
        
            
            
        
        
            Search Orders
        
    


    



    
        
            
                
                    Orders
                
            
        
            
                
                    Buy Again
                
            
        
            
                
                    Not Yet Shipped
                
            
        
            
                
                    Digital Orders
                
            
        
            
                
                    Local Store Orders
                
            
        
            
                
                    Cancelled Orders
                
            
        
    



    
        
            
    0 orders placed in

            
    
        
            last 30 days
        
    
        
            past 3 months
        
    
        
            2024
        
    
        
            2023
        
    
        
            2022
        
    
        
            2021
        
    
        
            2020
        
    
        
            2019
        
    
        
            Archived Orders
        
    

            past 3 months
        
        

        
            
        
    
    
        P.declare(&quot;time-filter-form-ready&quot;, {});
    



        

        
    An item you bought has been recalled
    To ensure your safety, go to Your Recalls and Product Safety Alerts and see recall information.



    .page-banner--hidden-by-default {
        display: none;
    }



    Action is required on one or more of your orders. 
    Please see below.



    .page-banner--hidden-by-default {
        display: none;
    }



    There&quot; , &quot;'&quot; , &quot;s a problem displaying your orders right now.
    



    .page-banner--hidden-by-default {
        display: none;
    }



    Shape the future of Amazon Digital Subscriptions.
    We have made updates to the Your Orders Page. Click here to &quot;Opt In&quot; to view the changes and/or provide your feedback. If you spot an issue, please report the bug here. For critical issues (Sev2+), please use TT.



    .page-banner--hidden-by-default {
        display: none;
    }








        
            
    
        Looks like you haven&quot; , &quot;'&quot; , &quot;t placed an order in the last 3 months.
        
            View orders in 2024
        
    

    
    if (typeof uet === &quot;function&quot;) { uet(&quot; , &quot;'&quot; , &quot;cf&quot; , &quot;'&quot; , &quot;); }





    


    
    if (typeof uet === &quot;function&quot;) { uet(&quot; , &quot;'&quot; , &quot;af&quot; , &quot;'&quot; , &quot;); }





    


    


        

        
        

        

        
            

    
    
    




        
    &quot;) or . = concat(&quot;
        
        


    
        
            
                
                    Your Account
                
                ›
            
        
            
                
                    Your Orders
                
            
        
    




    
        Your Orders
    
    
        
    
        
        
        
            
            
        
        
            Search Orders
        
    


    



    
        
            
                
                    Orders
                
            
        
            
                
                    Buy Again
                
            
        
            
                
                    Not Yet Shipped
                
            
        
            
                
                    Digital Orders
                
            
        
            
                
                    Local Store Orders
                
            
        
            
                
                    Cancelled Orders
                
            
        
    



    
        
            
    0 orders placed in

            
    
        
            last 30 days
        
    
        
            past 3 months
        
    
        
            2024
        
    
        
            2023
        
    
        
            2022
        
    
        
            2021
        
    
        
            2020
        
    
        
            2019
        
    
        
            Archived Orders
        
    

            past 3 months
        
        

        
            
        
    
    
        P.declare(&quot;time-filter-form-ready&quot;, {});
    



        

        
    An item you bought has been recalled
    To ensure your safety, go to Your Recalls and Product Safety Alerts and see recall information.



    .page-banner--hidden-by-default {
        display: none;
    }



    Action is required on one or more of your orders. 
    Please see below.



    .page-banner--hidden-by-default {
        display: none;
    }



    There&quot; , &quot;'&quot; , &quot;s a problem displaying your orders right now.
    



    .page-banner--hidden-by-default {
        display: none;
    }



    Shape the future of Amazon Digital Subscriptions.
    We have made updates to the Your Orders Page. Click here to &quot;Opt In&quot; to view the changes and/or provide your feedback. If you spot an issue, please report the bug here. For critical issues (Sev2+), please use TT.



    .page-banner--hidden-by-default {
        display: none;
    }








        
            
    
        Looks like you haven&quot; , &quot;'&quot; , &quot;t placed an order in the last 3 months.
        
            View orders in 2024
        
    

    
    if (typeof uet === &quot;function&quot;) { uet(&quot; , &quot;'&quot; , &quot;cf&quot; , &quot;'&quot; , &quot;); }





    


    
    if (typeof uet === &quot;function&quot;) { uet(&quot; , &quot;'&quot; , &quot;af&quot; , &quot;'&quot; , &quot;); }





    


    


        

        
        

        

        
            

    
    
    




        
    &quot;))]</value>
      <webElementGuid>87b57392-04f9-440c-9526-55dde7bb2179</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
