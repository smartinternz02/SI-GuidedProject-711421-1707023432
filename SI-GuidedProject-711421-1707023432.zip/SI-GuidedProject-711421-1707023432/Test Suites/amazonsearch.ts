<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>amazonsearch</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>3</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <rerunImmediately>true</rerunImmediately>
   <testSuiteGuid>fef20a6f-c204-406b-af3c-f17404a94de2</testSuiteGuid>
   <testCaseLink>
      <guid>909f8f41-1f60-4944-a6f1-5df3556baaf2</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Test2</testCaseId>
      <testDataLink>
         <combinationType>ONE</combinationType>
         <id>fcd2e1d0-964a-4303-b725-22bcd8f4fa63</id>
         <iterationEntity>
            <iterationType>ALL</iterationType>
            <value></value>
         </iterationEntity>
         <testDataId>Data Files/search</testDataId>
      </testDataLink>
      <usingDataBindingAtTestSuiteLevel>true</usingDataBindingAtTestSuiteLevel>
      <variableLink>
         <testDataLinkId>fcd2e1d0-964a-4303-b725-22bcd8f4fa63</testDataLinkId>
         <type>DATA_COLUMN</type>
         <value>search</value>
         <variableId>9b953ada-1941-40bb-9f15-17118e97cd1f</variableId>
      </variableLink>
   </testCaseLink>
</TestSuiteEntity>
